const {gunzipSync}=require('node:zlib');
let cache={};
async function get(url){const r=await fetch(url,{headers:{'User-Agent':'Mozilla/5.0'},signal:AbortSignal.timeout(12000)});if(!r.ok)throw Error('Provider unavailable');return r}
function plain(s){return s.replace(/<!\[CDATA\[([\s\S]*?)\]\]>/g,'$1').trim().replace(/&amp;/g,'&').replace(/&quot;/g,'"')}
module.exports=async(req,res)=>{
 try{
 const {kind,symbol=''}=req.query;
 if(kind==='quotes'){
 const symbols=[...new Set(symbol.toUpperCase().split(','))];if(symbols.length>15||symbols.some(s=>!/^([A-Z0-9&_-]{1,24}\.(NS|BO)|\^NSEI|\^NSEBANK|\^BSESN)$/.test(s)))return res.status(400).json({error:'Invalid symbols'});
 const quotes=await Promise.all(symbols.map(async s=>{try{const data=await(await get('https://query1.finance.yahoo.com/v8/finance/chart/'+encodeURIComponent(s)+'?interval=5m&range=1d')).json(),m=data.chart.result[0].meta;if(!Number.isFinite(m.regularMarketPrice)||!m.regularMarketTime)throw Error();return {s,price:m.regularMarketPrice,previous:m.chartPreviousClose,time:m.regularMarketTime*1000}}catch{return {s}}}));
 res.setHeader('Cache-Control','s-maxage=20');return res.json(quotes)
 }
 if(kind==='news'){
 let xml,aggregated=false;
 try{xml=await(await get('https://www.sebi.gov.in/sebirss.xml')).text();if(!/<item[ >]/i.test(xml))throw Error()}catch{aggregated=true;xml=await(await get('https://news.google.com/rss/search?q=SEBI+when:7d&hl=en-IN&gl=IN&ceid=IN:en')).text()}
 const rows=[...xml.matchAll(/<item\b[^>]*>([\s\S]*?)<\/item>/gi)].map(m=>{function tag(t){return plain(m[1].match(new RegExp('<'+t+'[^>]*>([\\s\\S]*?)</'+t+'>','i'))?.[1]||'')}return {title:tag('title'),url:tag('link'),date:tag('pubDate'),source:aggregated?'News coverage':'SEBI'}}).filter(x=>aggregated?x.url.startsWith('https://news.google.com/'): /^https?:\/\/(www\.)?sebi\.gov\.in\//i.test(x.url)).slice(0,12);
 if(!rows.length)throw Error();res.setHeader('Cache-Control','s-maxage=600');return res.json(rows)
 }
 if(kind==='expiries'){
 const exchange=symbol==='SENSEX'?'BSE':'NSE';if(!cache[exchange]||Date.now()-cache[exchange].at>3600000){
 const bytes=Buffer.from(await(await get('https://assets.upstox.com/market-quote/instruments/exchange/'+exchange+'.json.gz')).arrayBuffer());const rows=JSON.parse((bytes[0]===31?gunzipSync(bytes):bytes).toString());const groups={};
 for(const row of rows){if(row.instrument_type!=='CE'||row.underlying_type!=='INDEX')continue;const name=row.underlying_symbol;if(!groups[name])groups[name]=new Set();groups[name].add(new Date(Number(row.expiry)+19800000).toISOString().slice(0,10))}
 cache[exchange]={at:Date.now(),groups}}
 const today=new Date(Date.now()+19800000).toISOString().slice(0,10);const dates=[...(cache[exchange].groups[symbol]||[])].filter(d=>d>=today).sort();if(!dates.length)throw Error();res.setHeader('Cache-Control','s-maxage=900');return res.json(dates.slice(0,12))
 }
 return res.status(400).json({error:'Unknown request'})
 }catch{return res.status(503).json({error:'Provider unavailable'})}
}
